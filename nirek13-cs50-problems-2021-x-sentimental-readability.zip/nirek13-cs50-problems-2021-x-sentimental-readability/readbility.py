import str
text = input("Text")
l = 0
w = 0
s = 0
for i in range(len(text)): 
    if str.isalpha(i):
        l += 1
    if str.isspace(text[i]):
        w += 1
    if text[i] == "." or "!" or "?":
        s++
L = 100 * (l/w)
S = 100 * (s/w)

index = round(0.0588 * L - 0.296 * S - 15.8)

if index < 1:
    print("Before Grade 1")
if index > 16:
    print("Grade 16+")
else:
    print("Grade"+ index)