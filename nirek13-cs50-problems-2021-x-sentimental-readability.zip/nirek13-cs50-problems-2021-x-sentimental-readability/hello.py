a = input("What is your name?")
print("hello,"+ a)