import cs50
cash = -1
while cash < 0:
    cash = cs50.get_float("Change owed: ")
    cash = round(cash * 100)
change_used = 0
  
while cash >= 25:
    cash = cash - 25
    change_used += 1
while cash >= 10 and cash < 25:
    cash = cash - 10
    change_used += 1
while cash >= 5 and cash < 10:
    cash = cash - 5
    change_used += 1
while cash >= 1 and cash < 5:
    cash = cash - 1
    change_used += 1

print(change_used)

